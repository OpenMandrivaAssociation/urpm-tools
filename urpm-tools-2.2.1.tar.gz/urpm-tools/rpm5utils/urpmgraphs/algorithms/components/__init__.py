#from urpmgraphs.algorithms.components.connected import *
from rpm5utils.urpmgraphs.algorithms.components.strongly_connected import *
